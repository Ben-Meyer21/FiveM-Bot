const fetch = require('node-fetch');

async function getServerInfo(serverIp) {
    const response = await fetch(`http://${serverIp}/info.json`);
    if (!response.ok) {
        throw new Error('Failed to fetch server info');
    }
    return response.json();
}

async function getPlayers(serverIp) {
    const response = await fetch(`http://${serverIp}/players.json`);
    if (!response.ok) {
        throw new Error('Failed to fetch players');
    }
    return response.json();
}

module.exports = { getServerInfo, getPlayers };
