const fs = require('fs');
const http = require('http');
const { Client, Intents, Collection } = require('discord.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });

client.commands = new Collection();
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.name, command);
}

let serverConfig;
let startTime = Date.now();

client.once('ready', () => {
    console.log('Bot is online!');
    serverConfig = JSON.parse(fs.readFileSync('./data/servers.json', 'utf8'));
    client.user.setActivity('Managing Servers', { type: 'WATCHING' });
    client.startTime = startTime;
});

client.on('messageCreate', message => {
    if (!message.content.startsWith('!') || message.author.bot) return;

    const args = message.content.slice(1).split(/ +/);
    const commandName = args.shift().toLowerCase();

    if (!client.commands.has(commandName)) return;

    const command = client.commands.get(commandName);

    try {
        command.execute(message, args, client);
    } catch (error) {
        console.error(error);
        message.reply('There was an error trying to execute that command!');
    }
});

const server = http.createServer((req, res) => {
    if (req.method === 'POST' && req.url === '/fivem') {
        let body = '';

        req.on('data', chunk => {
            body += chunk.toString();
        });

        req.on('end', () => {
            const data = JSON.parse(body);
            const server = serverConfig.servers.find(s => s.ip === data.ip);
            if (server) {
                const channel = client.channels.cache.get(server.channelId);
                if (channel) {
                    channel.send(`Message from ${server.id}: ${data.message}`);
                }
            }
            res.end('ok');
        });
    } else {
        res.statusCode = 404;
        res.end();
    }
});

server.listen(3000, () => {
    console.log('HTTP server listening on port 3000');
});

client.login('YOUR_BOT_TOKEN'); // Replace with your bot token
