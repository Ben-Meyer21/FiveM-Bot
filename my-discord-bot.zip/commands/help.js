const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    name: 'help',
    description: 'Displays a help message with a list of commands.',
    async execute(message, args, client) {
        const commandsPerPage = 5;
        const commands = Array.from(client.commands.values());
        const totalPages = Math.ceil(commands.length / commandsPerPage);

        let currentPage = 0;

        const generateEmbed = (page) => {
            const start = page * commandsPerPage;
            const end = start + commandsPerPage;
            const commandList = commands.slice(start, end);

            const embed = new MessageEmbed()
                .setTitle('Help Menu')
                .setDescription('List of available commands')
                .setColor('#0099ff');

            commandList.forEach(command => {
                embed.addField(`!${command.name}`, command.description || 'No description provided.');
            });

            embed.setFooter(`Page ${page + 1} of ${totalPages}`);
            return embed;
        };

        const row = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId('previous')
                    .setLabel('Previous')
                    .setStyle('SECONDARY')
                    .setDisabled(currentPage === 0),
                new MessageButton()
                    .setCustomId('next')
                    .setLabel('Next')
                    .setStyle('SECONDARY')
                    .setDisabled(currentPage === totalPages - 1),
            );

        const embedMessage = await message.channel.send({ embeds: [generateEmbed(currentPage)], components: [row] });

        const filter = i => i.user.id === message.author.id;

        const collector = embedMessage.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async interaction => {
            if (interaction.customId === 'previous') {
                currentPage--;
            } else if (interaction.customId === 'next') {
                currentPage++;
            }

            await interaction.update({ embeds: [generateEmbed(currentPage)], components: [row] });

            row.components[0].setDisabled(currentPage === 0);
            row.components[1].setDisabled(currentPage === totalPages - 1);
        });

        collector.on('end', () => {
            const disabledRow = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('previous')
                        .setLabel('Previous')
                        .setStyle('SECONDARY')
                        .setDisabled(true),
                    new MessageButton()
                        .setCustomId('next')
                        .setLabel('Next')
                        .setStyle('SECONDARY')
                        .setDisabled(true),
                );

            embedMessage.edit({ components: [disabledRow] });
        });
    },
};
