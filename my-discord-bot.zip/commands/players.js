const { getPlayers } = require('../utils/fivem');

module.exports = {
    name: 'players',
    description: 'Shows the number of players online on the FiveM server.',
    async execute(message, args) {
        const serverId = args[0];
        if (!serverId) {
            return message.reply('Please provide the server ID.');
        }

        const serverConfig = require('../data/servers.json');
        const server = serverConfig.servers.find(s => s.id === serverId);

        if (!server) {
            return message.reply('Server not found.');
        }

        try {
            const players = await getPlayers(server.ip);
            message.channel.send(`There are currently ${players.length} players online on ${server.name}.`);
        } catch (error) {
            message.channel.send(`Failed to get players: ${error.message}`);
        }
    },
};
