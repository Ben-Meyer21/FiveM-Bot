module.exports = {
    name: 'ping',
    description: 'Ping command to check the bot\'s latency.',
    execute(message, args) {
        const sentTime = message.createdTimestamp;
        message.channel.send('Pong!').then(sent => {
            const latency = sent.createdTimestamp - sentTime;
            sent.edit(`Pong! Latency is ${latency}ms. API Latency is ${Math.round(message.client.ws.ping)}ms`);
        });
    },
};
