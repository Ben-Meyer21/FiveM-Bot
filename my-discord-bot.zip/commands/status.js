module.exports = {
    name: 'status',
    description: 'Shows the bot\'s status.',
    execute(message, args) {
        const status = message.client.user.presence.status;
        message.channel.send(`The bot's status is: ${status}`);
    },
};
