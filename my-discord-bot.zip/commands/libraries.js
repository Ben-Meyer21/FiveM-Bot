module.exports = {
    name: 'libraries',
    description: 'List the libraries used by the bot.',
    execute(message, args) {
        message.channel.send('The libraries used by this bot are:\n- discord.js\n- http\n- fs\n- node-fetch');
    },
};
