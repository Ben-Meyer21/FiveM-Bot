module.exports = {
    name: 'uptime',
    description: 'Shows the bot\'s uptime.',
    execute(message, args, client) {
        const uptime = Date.now() - client.startTime;
        const hours = Math.floor(uptime / 3600000);
        const minutes = Math.floor((uptime % 3600000) / 60000);
        const seconds = Math.floor((uptime % 60000) / 1000);
        message.channel.send(`The bot has been running for: ${hours}h ${minutes}m ${seconds}s`);
    },
};
