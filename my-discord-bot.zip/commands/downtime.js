module.exports = {
    name: 'downtime',
    description: 'Shows the bot\'s last restart time.',
    execute(message, args, client) {
        const restartTime = new Date(client.startTime).toLocaleString();
        message.channel.send(`The bot's last restart time was: ${restartTime}`);
    },
};
