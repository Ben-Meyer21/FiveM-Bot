const { getPlayers } = require('../utils/fivem');

module.exports = {
    name: 'admins',
    description: 'Shows the number of admins online on the FiveM server.',
    async execute(message, args) {
        const serverId = args[0];
        if (!serverId) {
            return message.reply('Please provide the server ID.');
        }

        const serverConfig = require('../data/servers.json');
        const server = serverConfig.servers.find(s => s.id === serverId);

        if (!server) {
            return message.reply('Server not found.');
        }

        try {
            const players = await getPlayers(server.ip);
            const admins = players.filter(player => 
                player.permissions && player.permissions.some(role => server.adminRoles.includes(role))
            );
            message.channel.send(`There are currently ${admins.length} admins online on ${server.name}.`);
        } catch (error) {
            message.channel.send(`Failed to get admins: ${error.message}`);
        }
    },
};
