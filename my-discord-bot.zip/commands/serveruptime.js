const { getServerInfo } = require('../utils/fivem');

module.exports = {
    name: 'serveruptime',
    description: 'Shows the uptime of the FiveM server.',
    async execute(message, args) {
        const serverId = args[0];
        if (!serverId) {
            return message.reply('Please provide the server ID.');
        }

        const serverConfig = require('../data/servers.json');
        const server = serverConfig.servers.find(s => s.id === serverId);

        if (!server) {
            return message.reply('Server not found.');
        }

        try {
            const info = await getServerInfo(server.ip);
            message.channel.send(`Server uptime for ${server.name} is: ${info.vars.sv_uptime}`);
        } catch (error) {
            message.channel.send(`Failed to get server uptime: ${error.message}`);
        }
    },
};
